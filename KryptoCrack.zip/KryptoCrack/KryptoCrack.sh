sudo python3 KryptoCrack.py
